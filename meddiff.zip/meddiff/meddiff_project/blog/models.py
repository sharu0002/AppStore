from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
from django.urls import reverse

class Post(models.Model):
	image = models.ImageField(default='default.jpg', upload_to='profile_pics')
	title = models.CharField(max_length=100)
	content = models.TextField()
	date_posted = models.DateTimeField(default=timezone.now)
	thumb = models.ImageField(default='default.png', blank=True)
	author = models.ForeignKey(User, on_delete=models.CASCADE, default=None)
	description = models.CharField(max_length=255, blank=True)
	document = models.FileField(upload_to='documents/', blank=True)
	
	def __str__(self):
		return self.title[:5] + '...'


	def snippet(self):
		return self.content[:50] + '...'

	def get_absolute_url(self):
		return reverse('post-detail', kwargs={'pk': self.pk})

class Document(models.Model):

    description = models.CharField(max_length=255, blank=True)
    document = models.FileField(upload_to='documents/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    title = models.CharField(max_length=100)
    content = models.TextField()
    thumb = models.ImageField(default='default.png', blank=True)

